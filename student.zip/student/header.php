<html>
  <head>
		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="style.css">
		<style>
		</style>
		<script>
		</script>
  </head>
	  <body>
		  <form>
			<div class="header">
			  <table>
				<tr>
				  <td><h2><i>Kgisl iAs Training</i></h2></td>
				  <td id="a"><button class="btn btn-default btn-lg"><a href="list.php">Home</a></button></td>
				 <!-- <td><button class="btn btn-default btn-lg"><a href="login.php">Login</a></button></td>-->
				  <td> <button class="btn btn-default btn-lg"><a href="adduser.php">Add new user</a></button></td>
				  </tr>
			  </table>
			</div>
			
				
			  </table>
			</div>
			</form>
	  </body>
</html>
