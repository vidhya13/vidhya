<?php
	include('header.php');
	include('config.php');


?>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="style.css">
	</head>
	<body>
		<form action="index.php" method="post">
			<div class="section">


				<table>
				</table>
			</div>



		</form>
	</body>
</html>
