-- phpMyAdmin SQL Dump
-- version 4.4.15.8
-- https://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 16, 2017 at 04:34 AM
-- Server version: 5.6.34
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cloudcoderdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `cc_courses`
--

CREATE TABLE IF NOT EXISTS `cc_courses` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `title` varchar(100) NOT NULL,
  `url` varchar(200) NOT NULL,
  `term_id` int(11) NOT NULL,
  `year` int(4) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cc_courses`
--

INSERT INTO `cc_courses` (`id`, `name`, `title`, `url`, `term_id`, `year`, `created_at`, `status`) VALUES
(1, 'CC demo', 'CC demo course', 'www.google.com', 1, 2016, '2016-10-25 05:14:07', 1),
(2, 'Test demo course', 'Cloud Coder Test course', 'www.google.com', 2, 2016, '2016-10-25 05:15:33', 1),
(3, 'Introduction Course', 'Cloud Coder Introduction Course', 'www.google.com', 3, 2016, '2016-10-25 05:16:14', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cc_groups`
--

CREATE TABLE IF NOT EXISTS `cc_groups` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cc_groups`
--

INSERT INTO `cc_groups` (`id`, `name`, `created_at`, `status`) VALUES
(1, 'admin', '2017-01-03 03:52:48', 1),
(2, 'mentor', '2017-01-03 03:53:02', 1),
(3, 'user', '2017-01-03 03:53:13', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cc_mentors`
--

CREATE TABLE IF NOT EXISTS `cc_mentors` (
  `id` int(11) NOT NULL,
  `mentor_id` int(11) NOT NULL,
  `mentor_username` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cc_mentors`
--

INSERT INTO `cc_mentors` (`id`, `mentor_id`, `mentor_username`, `date`, `time`) VALUES
(1, 36, '1132J37', '2016-03-17', '16:38:29'),
(2, 23, '12CSB2', '2016-03-21', '15:07:20'),
(3, 33, '1132J07', '2016-04-01', '13:48:56'),
(4, 47, '12CSB10', '2016-04-05', '11:09:08'),
(5, 49, '12CSA52', '2016-09-20', '08:57:54');

-- --------------------------------------------------------

--
-- Table structure for table `cc_mentor_mentees`
--

CREATE TABLE IF NOT EXISTS `cc_mentor_mentees` (
  `id` int(11) NOT NULL,
  `mentor_id` int(11) NOT NULL,
  `mentor_username` varchar(20) NOT NULL,
  `mentee_id` int(11) NOT NULL,
  `mentee_username` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `add_by` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cc_mentor_mentees`
--

INSERT INTO `cc_mentor_mentees` (`id`, `mentor_id`, `mentor_username`, `mentee_id`, `mentee_username`, `date`, `time`, `add_by`) VALUES
(53, 36, '1132J37', 0, '0932J02', '2016-03-17', '00:00:13', ''),
(55, 36, '1132J37', 0, '0932J03', '2016-03-17', '17:01:23', ''),
(66, 36, '1132J37', 0, '0932J05', '2016-03-18', '11:30:18', ''),
(72, 36, '1132J37', 0, '0932J06', '2016-03-18', '12:06:38', '1132J37'),
(73, 36, '1132J37', 0, '0932J07', '2016-03-18', '13:08:36', '1132J37'),
(101, 36, '1132J37', 23, '0932J01', '2016-03-21', '14:20:24', '1132J37'),
(104, 36, '1132J37', 45, '1132J35', '2016-03-31', '12:13:40', '1132J37'),
(105, 33, '1132J37', 45, '1132J36', '2016-04-01', '13:51:14', '1132J07'),
(106, 33, '1132J07', 45, '11cs29', '2016-04-01', '14:01:03', '1132J07'),
(107, 36, '1132J37', 45, '1132J21', '2016-04-01', '14:42:55', '1132J37'),
(108, 33, '1132J37', 46, '12CSB54', '2016-04-02', '08:59:27', '1132J07'),
(109, 36, '1132J37', 48, '12CSA34', '2016-04-05', '14:26:26', '1132J37'),
(110, 47, '12CSB10', 49, '12CSA52', '2016-04-12', '17:49:59', '12CSB10');

-- --------------------------------------------------------

--
-- Table structure for table `cc_modules`
--

CREATE TABLE IF NOT EXISTS `cc_modules` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cc_modules`
--

INSERT INTO `cc_modules` (`id`, `name`, `created_at`, `status`) VALUES
(1, 'A1-Array', '2016-10-25 06:23:34', 1),
(2, 'A1-Basic', '2016-10-25 06:23:42', 1),
(3, 'A1-Function', '2016-10-25 06:23:53', 1),
(4, 'Loop', '2016-10-25 06:24:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cc_problems`
--

CREATE TABLE IF NOT EXISTS `cc_problems` (
  `problem_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `module_id` int(11) NOT NULL,
  `assigned_date` varchar(100) NOT NULL,
  `due_date` varchar(100) NOT NULL,
  `visible` int(11) NOT NULL,
  `problem_authorship` int(11) NOT NULL DEFAULT '0',
  `deleted` int(11) NOT NULL DEFAULT '0',
  `shared` int(11) NOT NULL DEFAULT '0',
  `problem_type` varchar(100) NOT NULL,
  `testname` varchar(255) NOT NULL,
  `breif_description` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `skeleton` varchar(2000) NOT NULL,
  `author_name` varchar(80) NOT NULL,
  `author_email` varchar(80) NOT NULL,
  `author_website` varchar(100) NOT NULL,
  `license` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cc_problems`
--

INSERT INTO `cc_problems` (`problem_id`, `course_id`, `module_id`, `assigned_date`, `due_date`, `visible`, `problem_authorship`, `deleted`, `shared`, `problem_type`, `testname`, `breif_description`, `description`, `skeleton`, `author_name`, `author_email`, `author_website`, `license`, `created_at`, `status`) VALUES
(1, 1, 0, '11/10/2016', '11/10/2016', 0, 0, 0, 1, 'c', 'Hello World', 'print line', 'print line', '#include<stdio.h>\r\nint main()\r\n{\r\n	printf("Hello World");\r\nreturn 0;\r\n}\r\n\r\n', 'deepa', 'deepa@gmail.com', 'www.google.com', 'NOT REDISTRIBUTABLE', '2016-11-07 10:28:36', 1),
(6, 2, 0, '11/17/2016', '11/17/2016', 0, 0, 0, 1, 'python3', 'print hello world in python3', 'print hello world as output', 'print hello world as output', 'print("hello")\n\n#------Do not EDIT below this line ---------------\n\n#your code goes here\n', 'deepa', 'deepa@gmail.com', 'www.google.com', 'NOT REDISTRIBUTABLE', '2016-11-08 10:45:50', 1),
(7, 3, 0, '11/10/2016', '11/26/2016', 1, 0, 0, 1, 'c', 'Biggest of 3 numbers', 'Compare three numbers and find the biggest', 'Write a C program to find the biggest of three numbers.\r\n\r\nGet three numbers from user. i.e NUM1, NUM2 & NUM3.\r\n\r\nUse the proper conditional statement & display the biggest number.\r\n\r\n100, 150 & 200 => 200.\r\n\r\n-10, 30 & -150  => 30.', 'int main(){\r\n    // Your code goes here\r\n    return 0;\r\n}', 'suby', 'suby@gmail.com', 'www.google.com', 'NOT REDISTRIBUTABLE', '2016-11-10 07:53:18', 1),
(10, 1, 0, '11/11/2016', '04/13/2017', 0, 0, 0, 1, 'python', 'variable', 'sum the first two numbers in array', 'Check your basic assignment of values to variables with or without arithmetic operators.', 'def VAA1():\r\n    four    = 4\r\n    six     = 6\r\n    seven   = 7\r\n    ten     = four + six\r\n    \r\n    \r\n    \r\n    \r\n    \r\n    #------Do not EDIT below this line ---------------\r\n    print "Variable  seven has value:", seven #must print "7"\r\n    print "Variable  ten has value:",ten #must print "10"\r\n    \r\n    return seven, ten \r\n', 'vidhya', 'vidhya@gmail.com', 'www.google.com', 'NOT REDISTRIBUTABLE', '2016-11-11 04:06:35', 1),
(11, 1, 0, '12/08/2016', '12/08/2016', 1, 1, 0, 0, 'c', 'Biggest of 3 numbers using c', 'echo a line', 'Write a C program to find which is biggest number among the three given numbers.\r\n\r\n10, 20, 30 => Number three is Bigger\r\n\r\n20, 10, 15 => Number one is Bigger\r\n\r\n10, 80, 20 => Number two is Bigger', '#include<stdio.h>\r\n\r\nint main(){\r\n    \r\n    int number_one, number_two, number_three;\r\n    \r\n    // Get the input using scanf \r\n    \r\n    // Check if number one bigger\r\n    {\r\n        // Print "Number one is Bigger"\r\n    }\r\n    \r\n    // else if check number two is bigger\r\n    {\r\n        // Print "Number two is Bigger"\r\n    }\r\n    \r\n    // else number three should be printed as bigger\r\n    {\r\n        // Print "Number three is Bigger"\r\n    }\r\n    return 0;\r\n}', 'bvv', 'cvbbbbbbb', 'bvcvbv', 'bvcbvb', '2016-12-08 08:51:37', 1),
(12, 1, 0, '12/08/2016', '12/08/2016', 1, 0, 0, 0, 'PHP', 'Sum of two numbers using php', 'Initialize variables with sum values and print their sum', 'Initialize variables with sum values and print their sum\r\n\r\nExample\r\n1+1=2\r\n3+4=7', '<?php\r\n//initialize variables a,b with some values\r\n\r\n//declare c equals sum of a and b\r\n\r\n//print c\r\n\r\n?>', 'vidhya', 'vidhya.r@kggroup.com', 'google.com', 'fdfdf', '2016-12-08 08:55:47', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cc_terms`
--

CREATE TABLE IF NOT EXISTS `cc_terms` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `seq` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cc_terms`
--

INSERT INTO `cc_terms` (`id`, `name`, `seq`, `created_at`, `status`) VALUES
(1, 'Winter', 0, '2016-10-25 05:10:34', 1),
(2, 'Spring', 1, '2016-10-25 05:10:58', 1),
(3, 'Summer', 2, '2016-10-25 05:11:41', 1),
(4, 'Summer 1', 3, '2016-10-25 05:11:51', 1),
(5, 'Summer 2', 4, '2016-10-25 05:12:13', 1),
(6, 'Fall', 5, '2016-10-25 05:12:34', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cc_test_cases`
--

CREATE TABLE IF NOT EXISTS `cc_test_cases` (
  `id` int(11) NOT NULL,
  `problem_id` int(11) NOT NULL,
  `input` text NOT NULL,
  `output` varchar(200) NOT NULL,
  `testinput` varchar(200) NOT NULL,
  `message` varchar(150) NOT NULL,
  `secret` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cc_test_cases`
--

INSERT INTO `cc_test_cases` (`id`, `problem_id`, `input`, `output`, `testinput`, `message`, `secret`, `created_at`, `status`) VALUES
(1, 1, 'printf("hello");', 'hello', '', '', 0, '2016-11-09 10:00:43', 1),
(2, 7, 'printf("hello world");', 'hello world', '', '', 0, '2016-11-11 03:53:25', 1),
(3, 7, 'printf("hello");', 'hello', '', '', 0, '2016-11-11 04:07:14', 1),
(4, 10, 'print a line', 'hello world', '', '', 0, '2016-11-11 04:09:35', 1),
(5, 10, 'print a line', 'tytyyty', '', '', 1, '2016-11-11 04:10:05', 1),
(6, 10, 'c program', 'c++', '', '', 1, '2016-11-11 04:10:05', 1),
(7, 10, 'sdsd', 'hello world', '', '', 1, '2016-11-11 04:10:05', 1),
(9, 6, 'print("hello world")', 'hello world', 'Test Input(hello world)', 'Test passed for input hello world', 0, '2016-11-16 07:13:45', 1),
(10, 12, '$a', 'a', 'a', 'variable a with some value', 0, '2016-12-08 08:33:57', 1),
(11, 12, '$b', 'b', 'b', 'variable b with some value', 0, '2016-12-08 08:33:57', 1),
(12, 11, 'if(number_one >= number_two && number_one >= number_three)\r\n   ', 'Number two is Bigger', '10 20 10', 'Test passed for input (10 20 10)', 0, '2016-12-08 11:13:03', 1),
(13, 11, 'else if(number_two >= number_two && number_two >= number_three)\r\n  ', 'Number one is Bigger', '30 10 15', 'Test passed for input (30 10 15)', 0, '2016-12-08 11:35:09', 1),
(14, 11, 'else if(number_three >= number_two && number_three >= number_two)\r\n  ', 'Number three is Bigger', '10 20 80', 'Test passed for input (10 20 80)', 0, '2016-12-08 11:35:47', 1),
(15, 11, 'else if(number_two >= number_two && number_two >= number_three)\r\n  ', 'Number one is Bigger', '70 1 35', 'Test passed for input (70 1 35)', 0, '2016-12-08 11:38:48', 1),
(16, 12, '$c=$a+$b', 'c', '1+2', 'sum of a and b', 0, '2016-12-09 04:05:16', 1),
(17, 12, 'echo $c', 'value of c', 'c', 'sum of a and b', 0, '2016-12-09 04:06:16', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cc_user`
--

CREATE TABLE IF NOT EXISTS `cc_user` (
  `user_id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `firstname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lastname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alt_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `confirm_password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mobile_no` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `department` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `college` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `year` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `section` int(10) NOT NULL,
  `ismentor` int(11) NOT NULL,
  `isemail` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cc_user`
--

INSERT INTO `cc_user` (`user_id`, `username`, `firstname`, `lastname`, `email`, `alt_email`, `password`, `confirm_password`, `website`, `mobile_no`, `department`, `college`, `year`, `user_type`, `section`, `ismentor`, `isemail`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'vidhya', 'vidhya', 'rama', 'vidhya.r@kggroup.com', '', 'vid', 'vid', 'www.google.com', '9750856789', 'cs', 'psg', '2016', 'student', 5, 0, 0, 1, NULL, NULL, NULL),
(3, 'madhu', 'madhu', 'mathi', 'madhumathi.v@kggroup.com', '', 'madhu', 'madhu', 'www.google.com', '897654', 'cse', 'jsrji', '2016', 'instructor', 5, 0, 0, 1, NULL, '2016-10-18 10:37:48', NULL),
(5, 'ram', 'ram', 'leela', 'ram@gmail.com', '', 'ram', 'ram', 'www.ram.com', '786543280', 'maths', 'kg', '2012', 'instructor', 2, 1, 1, 1, NULL, '2016-10-19 03:28:13', NULL),
(7, 'raj', 'raja', 'rama', 'raja@gmail.com', '', 'raj', 'raj', 'www.yahoo.com', '76543245', 'maths', 'hindustan', '2011', 'instructor', 3, 1, 0, 1, NULL, '2016-10-19 03:42:44', NULL),
(49, 'manik', 'ma', 'po', 'manik@gmail.com', '', 'man', '', '', '978654309\r\n', '', '', '', '', 0, 0, 0, 1, NULL, '2016-10-20 07:24:51', NULL),
(51, 'keerthu', 'ke', 'th', 'keerthu@gmail.com', '', 'kee', '', '', '6789045678\r\n', '', '', '', '', 0, 0, 0, 1, NULL, '2016-10-20 07:24:51', NULL),
(53, 'naveen', 'nav', 'een', 'naveen@gmail.com', '', 'nav', '', '', '980987654\r\n', '', '', '', '', 0, 0, 0, 1, NULL, '2016-10-20 07:24:51', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cc_users`
--

CREATE TABLE IF NOT EXISTS `cc_users` (
  `id` int(10) NOT NULL,
  `username` varchar(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `phonenumber` int(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `IsMentor` varchar(10) NOT NULL,
  `website` varchar(50) NOT NULL,
  `consent` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cc_users`
--

INSERT INTO `cc_users` (`id`, `username`, `firstname`, `lastname`, `phonenumber`, `email`, `IsMentor`, `website`, `consent`, `password`) VALUES
(1, 'admin', 'ashok', 'b', 8765789, 'ashok@kgisl.com', 'yes', 'cbb', 'dd', 'admin'),
(23, '12CSB2', 'Poornima', 'S', 8754, 'spoornimaraji@gmail.com', 'yes', '', '', '123'),
(33, '1132J07', 'Dinesh kumar', 'C', 95666, 'dineshchinnasamy13@gmail.com', 'yes', 'www.google.com', 'dd', '12345'),
(34, '1132J38', 'vinoth', 'M', 100, 'vinoth38vm@gmail.com', 'yes', 'www.yahoo.com', 'dd', '58286'),
(36, '1132J37', 'vinoth kumar', 'S', 9655, 'vinothvin@yahoo.com', 'yes', 'www.yahoo.com', 'qq', '58286'),
(37, '1132J21', 'sabi', 'M', 100, 'ddd@gmail.com', 'no', 'dd', '1', '12345'),
(38, '1132J35', 'vignesh', 'J', 100, 'ddd@gmail.com', 'no', 'www.google.com', '', ''),
(43, '0932J02', 'Saranya', 'C', 2147483647, 'sarosaranya@gmail.vom', 'no', 'www.google.com', '', '12345'),
(45, '0932J01', 'Ramya', 'V', 956696, 'pramyaen@gmail.com', 'no', 'www.google.com', 'dd', '54321'),
(46, '12CSB54', 'Vishnu', 'Priya', 456789087, 'dhh', 'no', 'hhku', 'jn', '123'),
(47, '12CSB10', 'Divya', 'M', 62453898, 'fjf', 'yes', 'etg', 'dd', '1234'),
(48, '12CSA34', 'Geetha', 'A', 5456, 'asax', 'no', 'dcs', 'asf', 'c'),
(49, '12CSA52', 'Ranya', 'S', 5681, 'fdefj', 'yes', 'dm', 'fnvj', '123');

-- --------------------------------------------------------

--
-- Table structure for table `cc_user_groups`
--

CREATE TABLE IF NOT EXISTS `cc_user_groups` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cc_user_groups`
--

INSERT INTO `cc_user_groups` (`id`, `user_id`, `group_id`, `created_at`, `status`) VALUES
(1, 1, 1, '2017-01-03 03:55:10', 1),
(2, 23, 2, '2017-01-03 03:55:29', 1),
(3, 33, 3, '2017-01-03 03:55:35', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_log`
--

CREATE TABLE IF NOT EXISTS `user_log` (
  `user_log_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `login_date` varchar(20) NOT NULL,
  `logout_date` varchar(20) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=287 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_log`
--

INSERT INTO `user_log` (`user_log_id`, `username`, `login_date`, `logout_date`, `user_id`) VALUES
(1, '1132J07', '2016-03-02 11:02:52', '2016-04-20 18:06:47', 33),
(2, '1132J07', '2016-03-02 12:08:35', '2016-04-20 18:06:47', 33),
(3, '1132J07', '2016-03-02 12:12:47', '2016-04-20 18:06:47', 33),
(4, '1132J07', '2016-03-02 20:22:02', '2016-04-20 18:06:47', 33),
(5, '1132J21', '2016-03-03 00:11:50', '2016-04-06 15:10:12', 37),
(6, '1132J07', '2016-03-03 00:40:52', '2016-04-20 18:06:47', 33),
(7, '1132J21', '2016-03-03 14:38:49', '2016-04-06 15:10:12', 37),
(8, '1132J21', '2016-03-03 14:40:18', '2016-04-06 15:10:12', 37),
(9, '1132J07', '2016-03-03 14:40:49', '2016-04-20 18:06:47', 33),
(10, '1132J07', '2016-03-03 14:41:54', '2016-04-20 18:06:47', 33),
(11, '1132J07', '2016-03-03 14:46:06', '2016-04-20 18:06:47', 33),
(12, '1132J07', '2016-03-03 15:41:40', '2016-04-20 18:06:47', 33),
(13, '1132J21', '2016-03-03 15:49:32', '2016-04-06 15:10:12', 37),
(14, '1132J21', '2016-03-03 16:09:59', '2016-04-06 15:10:12', 37),
(15, '1132J21', '2016-03-03 16:10:44', '2016-04-06 15:10:12', 37),
(16, '1132J07', '2016-03-03 16:12:22', '2016-04-20 18:06:47', 33),
(17, '1132J21', '2016-03-03 16:13:13', '2016-04-06 15:10:12', 37),
(18, '1132J07', '2016-03-03 16:14:16', '2016-04-20 18:06:47', 33),
(19, '1132J21', '2016-03-03 16:16:53', '2016-04-06 15:10:12', 37),
(20, '1132J07', '2016-03-03 16:26:09', '2016-04-20 18:06:47', 33),
(21, '1132J07', '2016-03-07 14:34:59', '2016-04-20 18:06:47', 33),
(22, '1132J07', '2016-03-08 15:43:43', '2016-04-20 18:06:47', 33),
(23, '1132J07', '2016-03-08 16:11:29', '2016-04-20 18:06:47', 33),
(24, '1132J07', '2016-03-08 23:47:51', '2016-04-20 18:06:47', 33),
(25, '1132J07', '2016-03-09 09:59:49', '2016-04-20 18:06:47', 33),
(26, '1132J07', '2016-03-09 10:19:45', '2016-04-20 18:06:47', 33),
(27, '1132J21', '2016-03-09 10:21:05', '2016-04-06 15:10:12', 37),
(28, '1132J07', '2016-03-09 10:46:43', '2016-04-20 18:06:47', 33),
(29, '1132J21', '2016-03-09 11:06:52', '2016-04-06 15:10:12', 37),
(30, '1132J07', '2016-03-09 11:10:05', '2016-04-20 18:06:47', 33),
(31, '1132J07', '2016-03-10 22:05:41', '2016-04-20 18:06:47', 33),
(32, '1132J21', '2016-03-10 22:07:09', '2016-04-06 15:10:12', 37),
(33, '1132J07', '2016-03-10 22:25:04', '2016-04-20 18:06:47', 33),
(34, '1132J07', '2016-03-12 10:43:55', '2016-04-20 18:06:47', 33),
(35, '1132J07', '2016-03-14 14:34:57', '2016-04-20 18:06:47', 33),
(36, '1132J07', '2016-03-15 12:57:01', '2016-04-20 18:06:47', 33),
(37, '1132J07', '2016-03-15 13:04:03', '2016-04-20 18:06:47', 33),
(38, '1132J07', '2016-03-15 13:05:19', '2016-04-20 18:06:47', 33),
(39, '1132J07', '2016-03-16 11:54:36', '2016-04-20 18:06:47', 33),
(40, '1132J07', '2016-03-16 13:11:18', '2016-04-20 18:06:47', 33),
(41, '1132J07', '2016-03-16 13:18:31', '2016-04-20 18:06:47', 33),
(42, '1132J21', '2016-03-16 20:48:22', '2016-04-06 15:10:12', 37),
(43, '1132J07', '2016-03-16 22:07:27', '2016-04-20 18:06:47', 33),
(44, '1132J07', '2016-03-16 22:07:39', '2016-04-20 18:06:47', 33),
(45, '1132J21', '2016-03-16 22:08:08', '2016-04-06 15:10:12', 37),
(46, '1132J07', '2016-03-16 22:08:32', '2016-04-20 18:06:47', 33),
(47, '1132J07', '2016-03-16 22:10:23', '2016-04-20 18:06:47', 33),
(48, '1132J21', '2016-03-17 10:33:44', '2016-04-06 15:10:12', 37),
(49, '1132J07', '2016-03-17 13:00:47', '2016-04-20 18:06:47', 33),
(50, '1132J21', '2016-03-17 13:02:38', '2016-04-06 15:10:12', 37),
(51, '1132J37', '2016-03-17 17:15:51', '2016-04-13 11:02:31', 36),
(52, '1132J07', '2016-03-18 11:49:59', '2016-04-20 18:06:47', 33),
(53, '1132J37', '2016-03-18 12:06:11', '2016-04-13 11:02:31', 36),
(54, '1132J07', '2016-03-18 13:10:04', '2016-04-20 18:06:47', 33),
(55, '1132J07', '2016-03-21 12:08:34', '2016-04-20 18:06:47', 33),
(56, '1132J07', '2016-03-21 12:13:58', '2016-04-20 18:06:47', 33),
(57, '1132J37', '2016-03-21 14:13:06', '2016-04-13 11:02:31', 36),
(58, '1132J07', '2016-03-21 14:58:01', '2016-04-20 18:06:47', 33),
(59, '1132J07', '2016-03-21 15:41:59', '2016-04-20 18:06:47', 33),
(60, '1132J07', '2016-03-21 15:42:51', '2016-04-20 18:06:47', 33),
(61, '1132J07', '2016-03-21 15:45:06', '2017-01-04 14:29:49', 0),
(62, '1132J07', '2016-03-21 15:47:05', '2017-01-04 14:29:49', 0),
(63, '1132J07', '2016-03-21 16:05:14', '2016-04-20 18:06:47', 33),
(64, '1132J07', '2016-03-21 16:33:44', '2016-04-20 18:06:47', 33),
(65, '1132J37', '2016-03-21 16:36:47', '2016-04-13 11:02:31', 36),
(66, '1132J07', '2016-03-21 16:40:06', '2016-04-20 18:06:47', 33),
(67, '1132J37', '2016-03-21 20:29:15', '2016-04-13 11:02:31', 36),
(68, '1132J07', '2016-03-22 11:05:56', '2016-04-20 18:06:47', 33),
(69, '1132J07', '2016-03-22 11:46:44', '2016-04-20 18:06:47', 33),
(70, '1132J07', '2016-03-22 11:59:31', '2016-04-20 18:06:47', 33),
(71, '1132J07', '2016-03-24 10:45:42', '2016-04-20 18:06:47', 33),
(72, '1132J07', '2016-03-25 11:41:36', '2016-04-20 18:06:47', 33),
(73, '1132J07', '2016-03-25 16:48:23', '2016-04-20 18:06:47', 33),
(74, '1132J07', '2016-03-26 19:37:22', '2016-04-20 18:06:47', 33),
(75, '1132J07', '2016-03-28 11:44:16', '2016-04-20 18:06:47', 33),
(76, '1132J38', '2016-03-30 15:46:15', '2016-03-30 15:47:31', 34),
(77, '1132J37', '2016-03-30 16:06:11', '2016-04-13 11:02:31', 36),
(78, '1132J37', '2016-03-31 11:44:53', '2016-04-13 11:02:31', 36),
(79, '1132J07', '2016-03-31 14:17:15', '2016-04-20 18:06:47', 33),
(80, '1132J07', '2016-04-01 10:51:44', '2016-04-20 18:06:47', 33),
(81, '1132J07', '2016-04-01 11:20:00', '2016-04-20 18:06:47', 33),
(82, '1132J07', '2016-04-01 13:46:34', '2016-04-20 18:06:47', 33),
(83, '1132J37', '2016-04-01 14:04:31', '2016-04-13 11:02:31', 36),
(84, '1132J07', '2016-04-01 14:51:06', '2016-04-20 18:06:47', 33),
(85, '1132J07', '2016-04-02 08:53:13', '2016-04-20 18:06:47', 33),
(86, '12CSB54', '2016-04-02 09:02:49', '', 46),
(87, '12CSB54', '2016-04-02 09:03:13', '', 46),
(88, '1132J37', '2016-04-02 09:04:55', '2016-04-13 11:02:31', 36),
(89, '1132J07', '2016-04-02 16:05:01', '2016-04-20 18:06:47', 33),
(90, '1132J07', '2016-04-04 14:50:38', '2016-04-20 18:06:47', 33),
(91, '1132J07', '2016-04-05 11:12:37', '2016-04-20 18:06:47', 33),
(92, '1132J07', '2016-04-05 13:55:21', '2016-04-20 18:06:47', 33),
(93, '1132J37', '2016-04-05 14:18:59', '2016-04-13 11:02:31', 36),
(94, '1132J37', '2016-04-05 14:21:12', '2016-04-13 11:02:31', 36),
(95, '1132J21', '2016-04-06 10:46:52', '2016-04-06 15:10:12', 37),
(96, '1132J21', '2016-04-06 10:51:53', '2016-04-06 15:10:12', 37),
(97, '1132J07', '2016-04-06 11:58:22', '2016-04-20 18:06:47', 33),
(98, '1132J21', '2016-04-06 12:10:24', '2016-04-06 15:10:12', 37),
(99, '1132J21', '2016-04-06 13:11:54', '2016-04-06 15:10:12', 37),
(100, '1132J21', '2016-04-06 13:16:11', '2016-04-06 15:10:12', 37),
(101, '1132J21', '2016-04-06 15:11:02', '', 37),
(102, '1132J07', '2016-04-12 17:04:13', '2016-04-20 18:06:47', 33),
(103, '1132J07', '2016-04-12 17:05:14', '2016-04-20 18:06:47', 33),
(104, '12CSB10', '2016-04-12 17:48:41', '2016-04-12 22:11:40', 47),
(105, '1132J37', '2016-04-12 22:08:30', '2016-04-13 11:02:31', 36),
(106, '12CSB10', '2016-04-12 22:11:16', '2016-04-12 22:11:40', 47),
(107, '1132J07', '2016-04-13 11:00:19', '2016-04-20 18:06:47', 33),
(108, '1132J37', '2016-04-13 11:01:06', '2016-04-13 11:02:31', 36),
(109, '1132J07', '2016-04-13 11:02:42', '2016-04-20 18:06:47', 33),
(110, '1132J37', '2016-04-20 11:38:46', '', 36),
(111, '1132J37', '2016-04-20 11:39:19', '', 36),
(112, '1132J07', '2016-04-20 11:39:49', '2016-04-20 18:06:47', 33),
(113, '1132J07', '2016-04-20 14:17:43', '2016-04-20 18:06:47', 33),
(114, '1132J07', '2016-04-20 14:22:10', '2016-04-20 18:06:47', 33),
(115, '1132J07', '2016-04-20 15:27:41', '2016-04-20 18:06:47', 33),
(116, '1132J07', '2016-04-20 15:57:02', '2016-04-20 18:06:47', 33),
(117, '1132J07', '2016-04-20 16:23:33', '2016-04-20 18:06:47', 33),
(118, '1132J07', '2016-04-20 16:23:41', '2016-04-20 18:06:47', 33),
(119, '1132J07', '2016-04-20 17:05:44', '2016-04-20 18:06:47', 33),
(120, '1132J07', '2016-04-20 17:07:20', '2016-04-20 18:06:47', 33),
(121, '1132J07', '2016-04-20 17:17:07', '2016-04-20 18:06:47', 33),
(122, '1132J07', '2016-04-20 17:28:13', '2016-04-20 18:06:47', 33),
(123, '1132J07', '2016-04-20 17:51:50', '2016-04-20 18:06:47', 33),
(124, 'admin', '2016-04-20 18:16:55', '2017-01-04 12:43:41', 1),
(125, 'admin', '2016-04-20 18:36:26', '2017-01-04 12:43:41', 1),
(126, '1132J37', '2016-04-20 18:39:15', '', 36),
(127, '1132J07', '2016-04-21 08:31:02', '', 33),
(128, '1132J07', '2016-04-21 08:33:02', '', 33),
(129, 'admin', '2016-04-21 08:35:40', '2017-01-04 12:43:41', 1),
(130, 'admin', '2016-04-21 09:20:30', '2017-01-04 12:43:41', 1),
(131, '1132J07', '2016-04-21 09:27:42', '', 33),
(132, 'admin', '2016-05-26 12:52:01', '2017-01-04 12:43:41', 1),
(133, 'admin', '2016-05-26 12:53:57', '2017-01-04 12:43:41', 1),
(134, 'admin', '2016-05-26 12:56:31', '2017-01-04 12:43:41', 1),
(135, 'admin', '2016-09-01 08:45:09', '2017-01-04 12:43:41', 1),
(136, 'admin', '2016-09-02 09:49:52', '2017-01-04 12:43:41', 1),
(137, 'admin', '2016-09-06 14:02:22', '2017-01-04 12:43:41', 1),
(138, 'admin', '2016-09-08 21:56:23', '2017-01-04 12:43:41', 1),
(139, 'admin', '2016-09-08 21:56:27', '2017-01-04 12:43:41', 1),
(140, 'admin', '2016-09-14 11:47:04', '2017-01-04 12:43:41', 1),
(141, 'admin', '2016-09-14 11:47:04', '2017-01-04 12:43:41', 1),
(142, 'admin', '2016-09-19 10:03:39', '2017-01-04 12:43:41', 1),
(143, 'admin', '2016-09-20 08:49:29', '2017-01-04 12:43:41', 1),
(144, 'admin', '2016-09-20 09:54:47', '2017-01-04 12:43:41', 1),
(145, 'admin', '2016-09-20 10:05:59', '2017-01-04 12:43:41', 1),
(146, 'admin', '2016-09-20 13:21:39', '2017-01-04 12:43:41', 1),
(147, 'admin', '2016-09-21 09:23:39', '2017-01-04 12:43:41', 1),
(148, 'admin', '2016-09-21 09:31:11', '2017-01-04 12:43:41', 1),
(149, 'admin', '2016-09-21 09:52:28', '2017-01-04 12:43:41', 1),
(150, 'admin', '2016-09-21 09:53:15', '2017-01-04 12:43:41', 1),
(151, 'admin', '2016-09-21 11:19:45', '2017-01-04 12:43:41', 1),
(152, 'admin', '2016-09-27 14:42:11', '2017-01-04 12:43:41', 1),
(153, 'admin', '2016-09-28 08:48:14', '2017-01-04 12:43:41', 1),
(154, 'admin', '2016-09-29 08:54:41', '2017-01-04 12:43:41', 1),
(155, 'admin', '2016-09-29 14:50:59', '2017-01-04 12:43:41', 1),
(156, 'admin', '2016-09-29 17:51:51', '2017-01-04 12:43:41', 1),
(157, 'admin', '2016-09-30 10:55:48', '2017-01-04 12:43:41', 1),
(158, 'admin', '2016-09-30 13:26:15', '2017-01-04 12:43:41', 1),
(159, 'admin', '2016-09-30 17:08:58', '2017-01-04 12:43:41', 1),
(160, 'admin', '2016-10-03 16:29:41', '2017-01-04 12:43:41', 1),
(161, 'admin', '2016-10-04 14:18:15', '2017-01-04 12:43:41', 1),
(162, 'admin', '2016-10-06 09:07:35', '2017-01-04 12:43:41', 1),
(163, 'admin', '2016-10-07 08:49:05', '2017-01-04 12:43:41', 1),
(164, 'admin', '2016-10-11 08:57:40', '2017-01-04 12:43:41', 1),
(165, '0932J01', '2016-10-11 12:09:08', '2016-10-11 12:09:51', 45),
(166, 'admin', '2016-10-11 16:58:00', '2017-01-04 12:43:41', 1),
(167, 'admin', '2016-10-12 10:05:56', '2017-01-04 12:43:41', 1),
(168, 'admin', '2016-10-12 11:36:29', '2017-01-04 12:43:41', 1),
(169, 'admin', '2016-10-12 15:22:27', '2017-01-04 12:43:41', 1),
(170, 'admin', '2016-10-14 10:48:01', '2017-01-04 12:43:41', 1),
(171, 'admin', '2016-10-14 10:49:06', '2017-01-04 12:43:41', 1),
(172, 'admin', '2016-10-14 10:50:02', '2017-01-04 12:43:41', 1),
(173, 'admin', '2016-10-17 12:24:04', '2017-01-04 12:43:41', 1),
(174, 'admin', '2016-10-17 13:13:40', '2017-01-04 12:43:41', 1),
(175, 'admin', '2016-10-18 08:57:26', '2017-01-04 12:43:41', 1),
(176, 'admin', '2016-10-18 18:22:16', '2017-01-04 12:43:41', 1),
(177, 'admin', '2016-10-19 08:50:52', '2017-01-04 12:43:41', 1),
(178, 'admin', '2016-10-19 09:23:36', '2017-01-04 12:43:41', 1),
(179, 'admin', '2016-10-19 09:58:43', '2017-01-04 12:43:41', 1),
(180, 'admin', '2016-10-19 10:19:10', '2017-01-04 12:43:41', 1),
(181, 'admin', '2016-10-19 12:01:45', '2017-01-04 12:43:41', 1),
(182, 'admin', '2016-10-19 14:39:55', '2017-01-04 12:43:41', 1),
(183, 'admin', '2016-10-20 12:01:25', '2017-01-04 12:43:41', 1),
(184, 'admin', '2016-10-20 12:14:30', '2017-01-04 12:43:41', 1),
(185, 'admin', '2016-10-24 09:13:48', '2017-01-04 12:43:41', 1),
(186, 'admin', '2016-10-25 09:25:12', '2017-01-04 12:43:41', 1),
(187, 'admin', '2016-10-25 10:19:33', '2017-01-04 12:43:41', 1),
(188, 'admin', '2016-10-25 12:46:57', '2017-01-04 12:43:41', 1),
(189, 'admin', '2016-10-25 12:50:36', '2017-01-04 12:43:41', 1),
(190, 'admin', '2016-10-25 18:06:08', '2017-01-04 12:43:41', 1),
(191, 'admin', '2016-10-27 09:04:29', '2017-01-04 12:43:41', 1),
(192, 'admin', '2016-10-27 09:05:08', '2017-01-04 12:43:41', 1),
(193, 'admin', '2016-10-27 15:34:58', '2017-01-04 12:43:41', 1),
(194, 'admin', '2016-10-27 16:13:07', '2017-01-04 12:43:41', 1),
(195, 'admin', '2016-10-31 10:25:21', '2017-01-04 12:43:41', 1),
(196, 'admin', '2016-10-31 14:20:25', '2017-01-04 12:43:41', 1),
(197, 'admin', '2016-10-31 15:26:57', '2017-01-04 12:43:41', 1),
(198, 'admin', '2016-10-31 15:29:28', '2017-01-04 12:43:41', 1),
(199, 'admin', '2016-10-31 18:28:06', '2017-01-04 12:43:41', 1),
(200, 'admin', '2016-10-31 18:32:29', '2017-01-04 12:43:41', 1),
(201, 'admin', '2016-11-01 09:55:23', '2017-01-04 12:43:41', 1),
(202, 'admin', '2016-11-02 16:43:17', '2017-01-04 12:43:41', 1),
(203, 'admin', '2016-11-02 18:13:16', '2017-01-04 12:43:41', 1),
(204, 'admin', '2016-11-03 08:56:31', '2017-01-04 12:43:41', 1),
(205, 'admin', '2016-11-03 10:21:10', '2017-01-04 12:43:41', 1),
(206, 'admin', '2016-11-03 16:35:24', '2017-01-04 12:43:41', 1),
(207, 'admin', '2016-11-04 10:35:07', '2017-01-04 12:43:41', 1),
(208, 'admin', '2016-11-05 13:25:02', '2017-01-04 12:43:41', 1),
(209, 'admin', '2016-11-07 09:02:34', '2017-01-04 12:43:41', 1),
(210, 'admin', '2016-11-07 15:35:30', '2017-01-04 12:43:41', 1),
(211, 'admin', '2016-11-07 15:36:24', '2017-01-04 12:43:41', 1),
(212, 'admin', '2016-11-07 16:14:01', '2017-01-04 12:43:41', 1),
(213, 'admin', '2016-11-07 16:45:00', '2017-01-04 12:43:41', 1),
(214, 'admin', '2016-11-08 09:54:05', '2017-01-04 12:43:41', 1),
(215, 'admin', '2016-11-08 10:10:43', '2017-01-04 12:43:41', 1),
(216, 'admin', '2016-11-08 14:45:38', '2017-01-04 12:43:41', 1),
(217, 'admin', '2016-11-09 08:36:34', '2017-01-04 12:43:41', 1),
(218, 'admin', '2016-11-09 11:41:52', '2017-01-04 12:43:41', 1),
(219, 'admin', '2016-11-09 15:19:48', '2017-01-04 12:43:41', 1),
(220, 'admin', '2016-11-10 08:49:27', '2017-01-04 12:43:41', 1),
(221, 'admin', '2016-11-10 12:49:38', '2017-01-04 12:43:41', 1),
(222, 'admin', '2016-11-10 17:09:04', '2017-01-04 12:43:41', 1),
(223, 'admin', '2016-11-11 08:37:35', '2017-01-04 12:43:41', 1),
(224, 'admin', '2016-11-11 11:05:59', '2017-01-04 12:43:41', 1),
(225, 'admin', '2016-11-11 14:46:57', '2017-01-04 12:43:41', 1),
(226, 'admin', '2016-11-11 17:17:21', '2017-01-04 12:43:41', 1),
(227, 'admin', '2016-11-14 09:21:46', '2017-01-04 12:43:41', 1),
(228, 'admin', '2016-11-15 09:37:27', '2017-01-04 12:43:41', 1),
(229, 'admin', '2016-11-16 11:45:20', '2017-01-04 12:43:41', 1),
(230, 'admin', '2016-11-17 08:53:49', '2017-01-04 12:43:41', 1),
(231, 'admin', '2016-11-23 12:45:10', '2017-01-04 12:43:41', 1),
(232, 'admin', '2016-12-07 09:44:42', '2017-01-04 12:43:41', 1),
(233, 'admin', '2016-12-07 10:55:48', '2017-01-04 12:43:41', 1),
(234, 'admin', '2016-12-09 17:26:50', '2017-01-04 12:43:41', 1),
(235, 'admin', '2016-12-14 15:54:57', '2017-01-04 12:43:41', 1),
(236, 'admin', '2016-12-22 17:21:38', '2017-01-04 12:43:41', 1),
(237, 'admin', '2017-01-02 13:01:25', '2017-01-04 12:43:41', 1),
(238, 'admin', '2017-01-02 13:02:44', '2017-01-04 12:43:41', 1),
(239, 'admin', '2017-01-02 13:11:55', '2017-01-04 12:43:41', 1),
(240, 'admin', '2017-01-02 13:12:10', '2017-01-04 12:43:41', 1),
(241, 'admin', '2017-01-02 13:19:07', '2017-01-04 12:43:41', 1),
(242, 'admin', '2017-01-02 14:22:31', '2017-01-04 12:43:41', 1),
(243, 'admin', '2017-01-02 14:24:38', '2017-01-04 12:43:41', 1),
(244, 'admin', '2017-01-02 14:31:59', '2017-01-04 12:43:41', 1),
(245, 'admin', '2017-01-02 14:38:49', '2017-01-04 12:43:41', 1),
(246, 'admin', '2017-01-02 18:11:39', '2017-01-04 12:43:41', 1),
(247, '', '2017-01-02 18:17:32', '2017-01-04 14:29:49', 0),
(248, 'admin', '2017-01-02 18:17:44', '2017-01-04 12:43:41', 1),
(249, '', '2017-01-02 18:18:17', '2017-01-04 14:29:49', 0),
(250, '', '2017-01-02 18:20:11', '2017-01-04 14:29:49', 0),
(251, '', '2017-01-02 18:20:50', '2017-01-04 14:29:49', 0),
(252, '', '2017-01-02 18:22:28', '2017-01-04 14:29:49', 0),
(253, '', '2017-01-02 18:22:51', '2017-01-04 14:29:49', 0),
(254, '', '2017-01-02 18:23:30', '2017-01-04 14:29:49', 0),
(255, '', '2017-01-02 18:23:46', '2017-01-04 14:29:49', 0),
(256, '', '2017-01-02 18:24:26', '2017-01-04 14:29:49', 0),
(257, 'admin', '2017-01-03 08:46:06', '2017-01-04 12:43:41', 1),
(258, '', '2017-01-03 08:46:25', '2017-01-04 14:29:49', 0),
(259, '', '2017-01-03 08:46:48', '2017-01-04 14:29:49', 0),
(260, '', '2017-01-03 09:16:08', '2017-01-04 14:29:49', 0),
(261, '', '2017-01-03 10:19:55', '2017-01-04 14:29:49', 0),
(262, '', '2017-01-03 10:20:18', '2017-01-04 14:29:49', 0),
(263, '', '2017-01-03 10:24:48', '2017-01-04 14:29:49', 0),
(264, '', '2017-01-03 10:26:00', '2017-01-04 14:29:49', 0),
(265, '', '2017-01-03 10:26:06', '2017-01-04 14:29:49', 0),
(266, '', '2017-01-03 10:27:29', '2017-01-04 14:29:49', 0),
(267, '', '2017-01-03 10:28:24', '2017-01-04 14:29:49', 0),
(268, '', '2017-01-03 10:28:41', '2017-01-04 14:29:49', 0),
(269, '', '2017-01-03 10:30:13', '2017-01-04 14:29:49', 0),
(270, '12CSB2', '2017-01-03 10:31:52', '2017-01-03 11:45:38', 23),
(271, '', '2017-01-03 10:32:30', '2017-01-04 14:29:49', 0),
(272, '', '2017-01-03 10:33:34', '2017-01-04 14:29:49', 0),
(273, '', '2017-01-03 10:34:23', '2017-01-04 14:29:49', 0),
(274, 'admin', '2017-01-03 10:57:48', '2017-01-04 12:43:41', 1),
(275, '12CSB2', '2017-01-03 10:58:29', '2017-01-03 11:45:38', 23),
(276, '12CSB2', '2017-01-03 10:59:18', '2017-01-03 11:45:38', 23),
(277, '', '2017-01-03 10:59:42', '2017-01-04 14:29:49', 0),
(278, '', '2017-01-03 11:00:16', '2017-01-04 14:29:49', 0),
(279, '', '2017-01-03 11:00:24', '2017-01-04 14:29:49', 0),
(280, '1132J07', '2017-01-03 11:01:26', '', 33),
(281, '12CSB2', '2017-01-03 11:02:33', '2017-01-03 11:45:38', 23),
(282, '12CSB2', '2017-01-03 11:03:23', '2017-01-03 11:45:38', 23),
(283, 'admin', '2017-01-03 11:03:40', '2017-01-04 12:43:41', 1),
(284, '12CSB2', '2017-01-03 11:28:26', '2017-01-03 11:45:38', 23),
(285, '12CSB2', '2017-01-03 11:45:32', '2017-01-03 11:45:38', 23),
(286, 'admin', '2017-01-03 13:01:27', '2017-01-04 12:43:41', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cc_courses`
--
ALTER TABLE `cc_courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cc_groups`
--
ALTER TABLE `cc_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cc_mentors`
--
ALTER TABLE `cc_mentors`
  ADD PRIMARY KEY (`id`,`mentor_id`);

--
-- Indexes for table `cc_mentor_mentees`
--
ALTER TABLE `cc_mentor_mentees`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `mentee_username` (`mentee_username`),
  ADD UNIQUE KEY `mentee_username_2` (`mentee_username`);

--
-- Indexes for table `cc_modules`
--
ALTER TABLE `cc_modules`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cc_problems`
--
ALTER TABLE `cc_problems`
  ADD PRIMARY KEY (`problem_id`);

--
-- Indexes for table `cc_terms`
--
ALTER TABLE `cc_terms`
  ADD PRIMARY KEY (`id`),
  ADD KEY `seq` (`seq`);

--
-- Indexes for table `cc_test_cases`
--
ALTER TABLE `cc_test_cases`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cc_user`
--
ALTER TABLE `cc_user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `cc_users_username_unique` (`username`),
  ADD UNIQUE KEY `cc_users_email_unique` (`email`),
  ADD UNIQUE KEY `cc_users_mobile_no_unique` (`mobile_no`);

--
-- Indexes for table `cc_users`
--
ALTER TABLE `cc_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`,`email`);

--
-- Indexes for table `cc_user_groups`
--
ALTER TABLE `cc_user_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_log`
--
ALTER TABLE `user_log`
  ADD PRIMARY KEY (`user_log_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cc_courses`
--
ALTER TABLE `cc_courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `cc_groups`
--
ALTER TABLE `cc_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `cc_mentors`
--
ALTER TABLE `cc_mentors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `cc_mentor_mentees`
--
ALTER TABLE `cc_mentor_mentees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=111;
--
-- AUTO_INCREMENT for table `cc_modules`
--
ALTER TABLE `cc_modules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `cc_problems`
--
ALTER TABLE `cc_problems`
  MODIFY `problem_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `cc_terms`
--
ALTER TABLE `cc_terms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `cc_test_cases`
--
ALTER TABLE `cc_test_cases`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `cc_user`
--
ALTER TABLE `cc_user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=54;
--
-- AUTO_INCREMENT for table `cc_users`
--
ALTER TABLE `cc_users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=50;
--
-- AUTO_INCREMENT for table `cc_user_groups`
--
ALTER TABLE `cc_user_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `user_log`
--
ALTER TABLE `user_log`
  MODIFY `user_log_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=287;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
