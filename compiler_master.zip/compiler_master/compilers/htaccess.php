Order Allow,Deny
Deny from all
