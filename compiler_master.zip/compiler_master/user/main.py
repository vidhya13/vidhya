def VAA1():
    four    = 4
    six     = 6
    seven   = 7
    ten     = four + six
    
    
    
    
    
    #------Do not EDIT below this line ---------------
    print "Variable  seven has value:", seven #must print "7"
    print "Variable  ten has value:",ten #must print "10"
    
    return seven, ten 
