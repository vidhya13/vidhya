<!-- Footer -->
<div class="wrapper row4">
  <footer id="footer" class="clear">
    <p class="fl_left">Copyright &copy; 2017 - All Rights Reserved - <a href="#">Cloud based Bus Pass System</a></p>
    <p class="fl_right">Done By <a href="#" title="Free Website Templates" style="color:pink">Suganya</a></p>
  </footer>
</div>
</body>
</html>