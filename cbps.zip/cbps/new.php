<?php include ("head.php");?>
<?php
	if(!empty($_POST))
	{
		$db = mysqli_connect('localhost','root','','busdb');	
		$qry = 'INSERT INTO users (`user_name`,display_name,city,pin_code,mobileno,email_id,password) VALUES ("'.$_POST['user_name'].'","'.$_POST['display_name'].'","'.$_POST['city'].'","'.$_POST['pincode'].'","'.$_POST['mobileno'].'","'.$_POST['email_id'].'","'.$_POST['password'].'")';
		
		mysqli_query($db,$qry);
	//	echo $qry; exit;
		echo "<script> window.location = 'index.php'; </script>";
	}		
	?>

<div class="wrapper row2">
<nav id="topnav1">
<center>
<title>new account</title>
<form method='post' enctype='multipart/form-data'>
<table style='width:25%'>
<h1>create new account</h1>
<tr>
<td>Name</td>
<td><input type="text" name="display_name" size="30"></td>
</tr>
<tr>
<td>UserName</td>
<td><input type="text" name="user_name" size="30"></td>
</tr>
<tr>
<td>city</td>
<td><input type="text" name="city" size="30"></td>
</tr>
<tr>
<td>pincode</td>
<td><input type="text" name="pincode" size="30"></td>
</tr>
<tr>
<td>email_id</td>
<td><input type="text" name="email_id" size="30"></td>
</tr>
<tr>
<td>mobile_no</td>
<td><input type="text" name="mobile_no" size="30"></td>
</tr>
<tr>
<td>password</td>
<td><input type="password" name="password" size="30"></td>
</tr>
</table>
<button onclick="submit">submit</button>
<input type="button" value="cancel">
</center>
</form>
</div>
</div>
<?php include ("foot.php");?>