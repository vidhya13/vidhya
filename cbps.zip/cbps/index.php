<?php 
$page = "index";
include ("head.php");?>

	<?php
		$db = mysqli_connect('localhost','root','','busdb');	
	if(!empty($_POST))
	{
		$qry = "select id from users where email_id = '{$_POST['email_id']}' AND password = '{$_POST['password']}'";
		$opt = mysqli_query($db,$qry);
		
		$res = mysqli_fetch_array($opt);
		
		if(!empty($res))
		{
			
			//header('Location:suga.php',true);
			
				echo "<script> window.location = 'reg.php?page=view&id='; </script>";
			exit;
			
		}
		
		echo "<script> alert('Invaid User..'); </script>";
	}	
	?>

<div class="wrapper row2">
<nav id="topnav1">
<form method='post' enctype='multipart/form-data'>
<center>
<h1>login page</h1>
<lable>Email-id</lable>
<input type="text" name="email_id">
<br><br>
<lable>password</lable>
<input type="password" name="password">
<br><br>
<input type="submit" value="sing in" name="Login">
<a href='new.php'>Sign up </a>
</center>
</form>
</div>
</div>
<?php include ("foot.php");?>
