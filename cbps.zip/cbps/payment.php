<?php include ("head.php");?>
<?php
	if(!empty($_POST))
	{
		$db = mysqli_connect('localhost','root','','busdb');	
		
		$qry = "INSERT INTO payment (fullname,accountno,bankname,branch,city,amount) 
		VALUES ('{$_POST['fullname']}','{$_POST['accountno']}','{$_POST['bankname']}','{$_POST['city']}',
		'{$_POST['branch']}','{$_POST['amount']}')";
		mysqli_query($db,$qry);
		
	//	echo $qry; exit;
		echo "<script> window.location = 'newpass.php'; </script>";
	}		
	?>
	<div class="wrapper row2">
  <nav id="topnav1">
  <form method='post'enctype='multipart/form-data'>
<center><h1>Payment Getway</h1>
<table style='width:20%'>
<tr>
<td>fullname</td>
<td><input type="text" name="fullname" size="30"></td>
</tr>
<tr>
<td>accountno</td>
<td><input type="text" name="accoundno" size="30"></td>
</tr>
<tr>
<td>bankname</td>
<td><select name="bank name">
<option value="-1"selected>select..</option>
<option value="sbi">SBI</option>
<option value="icici">ICICI</option>
<option value="iob">IOB</option>
</td></tr>
<tr>
<td>brache</td>
<td><select name="brache">
<option value="-1"selected>select..</option>
<option value="saravanampatti">SARAVANAMPATTI</option>
<option value="sarkarsamkulam">SARKARSAMKULAM</option>
</td></tr>
<tr>
<td>city</td>
<td><select name="brache">
<option value="-1"selected>select..</option>
<option value="coimbatore">COIMBATORE</option>
<option value="chanani">CHANANI</option>
</td></tr>
<tr>
<td>amount</td>
<td><input type="text" name="fullname" size="30"></td>
</tr>
</table>
<input type="submit"value="submit">
<input type="button"value="cancel">
</center>
</form>
</div>
</div>
<?php include ("foot.php");?>