<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
<title>bus pass system</title>
<meta charset="iso-8859-1">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="styles/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="styles/mediaqueries.css" type="text/css" media="all">
<script src="scripts/jquery.1.9.0.min.js"></script>
<script src="scripts/jquery-mobilemenu.min.js"></script>
<!--[if lt IE 9]>
<link rel="stylesheet" href="styles/ie.css" type="text/css" media="all">
<script src="scripts/ie/css3-mediaqueries.min.js"></script>
<script src="scripts/ie/ie9.js"></script>
<script src="scripts/ie/html5shiv.min.js"></script>
<![endif]-->
<!-- BEFORE USING THIS FRAMEWORK REMOVE THIS DEMO STYLING - ONLY USED TO EMPHASISE THE DIV CONTAINERS IN THE CONTENT AREA -->
<style type="text/css">
div.full_width{margin-top:20px;}
div.full_width:first-child{margin-top:0;}
div.full_width div{color:#666666; background-color:#DEDEDE;}
</style>
<!-- END DEMO STYLING -->
</head>
<body>
<div class="wrapper row1">
  <header id="header" class="clear">
    <div id="hgroup">
    <center> <h2>BUS PASS SYSTEM</h2> </center>
    </div>
  </header>
</div>
<!-- ################################################################################################ -->
<div class="wrapper row2">
  <nav id="topnav">
    <ul class="clear">
      <li class="active first"><a href="home.php">Homepage</a></li>
      <li><a class="drop" href="index.php">lOGIN</a></li>
	  
	  <?php 
	 
	  if($page == "INDEX")
	  { ?>
		  <li><a href="new.php">NEWACCOUNT</a></li>
      <li><a href="reg.php">REGISTER</a></li>
      <li><a href="payment.php">PAYMENT </a></li>
      <li><a href="newpass.php">NEWPASS</a></li>
      <li class="last-child"><a class="drop" href="renewalpass.php">RENEWAL</a></li>
		  
	 <?php  }
      ?>
        </ul>
      </li>
    </ul>
  </nav>
</div>
<!-- content -->
