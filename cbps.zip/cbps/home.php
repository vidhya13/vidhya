<?php include ("head.php");?>

<div class="wrapper row2">
<nav id="topnav1">
</div>
</div>
<?php include ("foot.php");?>