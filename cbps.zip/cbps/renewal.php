
<html>
<head>
<script>
function fun(){
	
	window.print();
}
</script>
</head>
</html>
<?php if(!isset($_GET['page']))
{
	include ("head.php");
}
	?>

<?php
//print_r($_GET['page']);
$db = mysqli_connect('localhost','root','','busdb');	


if(isset($_GET['page']) && $_GET['page'] != 'add')
{
	$id = $_GET['id'];
	
	$qry = "select * from new where id = '{$id}'";
	$opt = mysqli_query($db,$qry);
		
		$res = mysqli_fetch_assoc($opt);

	$name = $res['name'];
	$mobileno = $res['mobileno'];
	$amount = $res['amount'];
	$validate = $res['validate'];
	$to = $res['to'];
	$st_point = $res['startpoint'];
	$et_point = $res['endpoint'];
	$photo=$res['photo'];
}
else
{
	$name = "";
	$mobileno = "";
	$amount = "";
	$validate = "";
	$to = "";
	$st_point = "";
	$et_point = "";
	$photo="";
}
if(!empty($_POST))
	{
		
		move_uploaded_file($_FILES['photo']['tmp_name'], "image/{$_POST['name']}_{$_FILES['photo']['name']}"); 
		
		
	 	$qry = "INSERT INTO new (name,mobileno,amount,validate,`to`,startpoint,endpoint,photo) VALUES ('{$_POST['name']}','{$_POST['mobileno']}','{$_POST['amound']}','{$_POST['validate']}','{$_POST['to']}','{$_FILES['photo']['image']}','{$_POST['startpoint']}','{$_POST['endpoint']}')";
		mysqli_query($db,$qry);
		
		$id = mysqli_insert_id($db);
		
		echo "<script> window.location = 'payment.php?page=view&id={$id}'; </script>";
	}		
?>
<form method='post' enctype='multipart/form-data'>
<center>
<h1>renewalpass</h1>
<div style=''>
<label>name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
<?php
if($_GET['page'] != 'view')
{
	
echo "<input type='text' value='{$name}' name='name'>";
}
else
{
	echo $name;
}
 ?>
<br><br>

<label>mobileno &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
<?php
if($_GET['page'] != 'view')
{
	
echo "<input type='text' value='{$mobileno}' name='mobileno'>";
}
else
{
	echo $mobileno;
}
?>
<br><br>

<label>amount &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
<?php
if($_GET['page'] != 'view')
{
	
echo "<input type='text' value='{$amount}' name='amount'>";
}
else
{
	echo $amount;
}
?>
<br><br>

<label>validate &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
<?php
if($_GET['page'] != 'view')
{
	
echo "<input type='text' value='{$validate}' name='validate'>";
}
else
{
	echo $validate;
}
?>
<br><br>

<label>to &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
<?php
if($_GET['page'] != 'view')
{
	
echo "<input type='text' value='{$to}' name='to'>";
}
else
{
	echo $to;
}
?>
<br><br>
<label>startpoint &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
<?PHP

if($_GET['page'] != 'view')
{ ?>
<select name='startpoint'>
		<option value='-1'>-- select-- </OPTION>
		<option value='thevampalyam' <?php if($st_point == 'thevampalayam') echo "selected"; ?> >thevampalayam</optopn>
        <option value='sravanampatti' <?php if($st_point == 'saravanamptti') echo "selected"; ?> >saravanamptti</option>
        <option value='kgcas' <?php if($st_point == 'kgcas') echo "selected"; ?> >kgcas</option>
        </select>
<?php
} 
else
echo $st_point;
?>
<br><br>

<label>endpoint &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>

<?PHP
if($_GET['page'] != 'view')
{ ?>
<select name='startpoint'>
		<option value='-1'>-- Select -- </option>
		<option value='thevampalayam' <?php if($et_point == 'thevampalayam') echo "selected"; ?> >thevampalayam</option>
        <option value='saravanmpatti' <?php if($et_point == 'saravanampatti') echo "selected";?> >saravanampatti</option>
        <option value='kgcas' <?php if($et_point ='kgcas') echo "selected";?> >kgcas</option>
        </select>
<?PHP
} 
else
echo $et_point;
?>
<br><br>
<label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;photo</label>
<?php
if($_GET['page'] == 'view')
{
?>	
<img src="sy.jpg" style="width:100px;height:100px">

<?php
}
if($_GET['page'] != 'view')
{
	
?>

<input type='file' value='{$photo}' name='to'>
<?php
}
else
{
	echo $photo;
}
?>
<br><br>			
<?php if($_GET['page'] != 'view') { ?>
<input type="submit" value="Save">
<input type="button" value="cancel">
<?php } if($_GET['page'] == 'view'){?>
<button onclick="fun()">Print</button>
<a href="index.php">Back</a>
<?php } ?>
</div>

</center>
</form>
</div>
</div>
<?php if($_GET['page'] != 'view')
{
	include ("foot.php");
	}?>