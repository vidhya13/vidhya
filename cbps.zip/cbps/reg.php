<?php include ("head.php");?>

<?php
	if(!empty($_POST))
	{
		$db = mysqli_connect('localhost','root','','busdb');	
		
		move_uploaded_file($_FILES['photo']['tmp_name'], "image/{$_POST['name']}_{$_FILES['photo']['name']}"); 
		
		$qry = "INSERT INTO reg (firstname,lastname,gander,age,date_of_birth,	address,mobileno,email_id,cost,bus_type,duration,image) 
		VALUES ('{$_POST['firtname']}','{$_POST['lastname']}','{$_POST['gender']}','{$_POST['age']}',
		'{$_POST['date_of_birth']}','{$_POST['address']}','{$_POST['mobileno']}','{$_POST['email_id']}',
		'{$_POST['cost']}','{$_POST['bustype']}','{$_POST['duration']}','{$_FILES['photo']['image']}')";
		
		//echo $qry; exit;
		mysqli_query($db,$qry);
				
		echo "<script> window.location = 'payment.php'; </script>";
	}		
	?>
	<div class="wrapper row2">
  <nav id="topnav1">
<center>
<n1>Registr	ation from</h1>
<form method="post" enctype='multipart/form-data'>
<table bodar="1" style='width:50&'>
<tr>
<td>firstname</td>
<td><input type="text" name="firtname" size="30"><td>
</tr>
<tr>
<td>lastname</td>
<td><input type="text" name="lastname" size="30"><td>
</tr>
<tr>
<td>gander</td>
<td><input type="radio" name="gender" value="male">male<input type="radio" name="gender" value="female">female</td>
</tr>
<tr>
<td>age</td>
<td><input type="text" name="age" size="30"></td>
</tr>
<tr>
<td>date of birth</td>
<td><input type="text" value='' name="date_of_birth" size="30"></td>
</tr>
<tr>
<td>address</td>
<td><input type="text" name="address" size="30"></td>
</tr>
<tr>
<td>mobileno</td>
<td><input type="text" name="mobileno" size="30"></td>
</tr>
<tr>
<td>Photo</td>
<td><input type="file" name="photo" size="30"></td>
</tr>
<tr>
<td>Email id</td>
<td><input type="text" name="email_id" size="30"></td>
</tr>
<tr>
<td>cost</td>
<td><input type="text" name="cost" size="30"></td>
</tr>
<tr>
<td>bus type</td>
<td><select name='bustype'>
		<option value='-1'>-- Select -- </option>
		<option value='ordinary'>ordinary</option>
        <option value='air bus'>airbus</option>
        <option value='metro'>metro</option>
        <option value='metrodelux'>metrodelux</option>
		</select></td>
		</tr>
<tr>
<td>duration</td>
<td><select name='duration'>
        <option value='-1'>-- Select -- </option>
		<option value='1month'>1month</option>
		<option value='2month'>2month</option>
		<option value='1month'>1month</option>
		<option value='2month'>2month</option>
		</select></td>
		</tr>
</table>
<input type="submit" value="submit" name="submit">
<input type="button" value="cancal">
</form>
</center>
</div>
</div>
<?php include ("foot.php");?>