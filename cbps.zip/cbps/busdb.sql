-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 07, 2017 at 03:20 AM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `busdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `new`
--

CREATE TABLE IF NOT EXISTS `new` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `name` varchar(100) NOT NULL,
  `amount` int(100) NOT NULL,
  `mobileno` varchar(30) NOT NULL,
  `validate` varchar(50) NOT NULL,
  `to` varchar(50) NOT NULL,
  `startpoint` varchar(100) NOT NULL,
  `endpoint` varchar(100) NOT NULL,
  `photo` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `new`
--

INSERT INTO `new` (`id`, `status`, `created_at`, `name`, `amount`, `mobileno`, `validate`, `to`, `startpoint`, `endpoint`, `photo`) VALUES
(1, 0, '2017-03-07 02:31:48', 'h', 0, 'hu', 'uh', 'u', 'kgcas', 'fsdfdsf', '170307023212Lenovo_A1000_IMG_20151129_230020.jpg'),
(2, 0, '2017-03-07 03:09:05', 'suganya', 0, '9655589215', '1/1/17', '30/1/17', 'kgcas', '', '1703070309292013-05-27 17.23.37-1-1.jpg'),
(3, 0, '2017-03-07 03:09:36', 'suganya', 0, '9655589215', '1/1/17', '30/1/17', 'thevampalayam', '', '1703070310002013-05-27 17.23.37-1-1.jpg'),
(4, 0, '2017-03-07 03:11:31', 'suganya', 0, '9655589215', '1/1/17', '30/1/17', 'thevampalayam', '', '1703070311552013-05-27 17.23.37-1-1.jpg'),
(5, 0, '2017-03-07 03:16:14', 'suganya', 0, '9655589215', '1/1/17', '30/1/17', 'thevampalayam', '', '1703070316382013-05-27 17.23.37-1-1.jpg'),
(6, 0, '2017-03-07 03:16:30', 'suganya', 0, '9655589215', '1/1/17', '30/1/17', 'thevampalayam', '', '1703070316542013-05-27 17.23.37-1-1.jpg'),
(7, 0, '2017-03-07 03:19:36', 'suganya', 0, '4545454', 'ffg', '30/1/17', 'thevampalyam', 'saravanmpatti', '1703070320002013-05-27 17.23.37-1-1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE IF NOT EXISTS `payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fullname` varchar(100) NOT NULL,
  `accountno` int(20) NOT NULL,
  `bankname` varchar(100) NOT NULL,
  `branch` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `amount` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `status`, `created_at`, `fullname`, `accountno`, `bankname`, `branch`, `city`, `amount`) VALUES
(1, 0, '2017-02-15 03:00:14', '150', 0, '', '', '', 0),
(2, 0, '2017-02-16 02:24:46', '', 0, '', '', '', 0),
(3, 0, '2017-02-16 03:55:30', '150', 0, '', '', '', 0),
(4, 0, '2017-02-21 01:42:50', '150', 0, '', '', '', 0),
(5, 0, '2017-02-21 02:47:26', '15', 0, '', '', '', 0),
(6, 0, '2017-03-03 08:19:41', '', 0, '', '', '', 0),
(7, 0, '2017-03-03 08:20:59', '', 0, '', '', '', 0),
(8, 0, '2017-03-07 03:08:28', '150', 0, '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `reg`
--

CREATE TABLE IF NOT EXISTS `reg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` int(11) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `gander` varchar(100) NOT NULL,
  `age` varchar(25) NOT NULL,
  `date_of_birth` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `mobileno` varchar(100) NOT NULL,
  `email_id` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  `cost` varchar(100) NOT NULL,
  `bus_type` varchar(100) NOT NULL,
  `duration` varchar(100) NOT NULL,
  `image` blob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `reg`
--

INSERT INTO `reg` (`id`, `status`, `created_at`, `firstname`, `lastname`, `gander`, `age`, `date_of_birth`, `address`, `mobileno`, `email_id`, `password`, `cost`, `bus_type`, `duration`, `image`) VALUES
(1, 1, '2017-03-07 02:04:05', 'ioi', 'o', '', 'oi', 'oi', 'oi', 'oi', 'oi', '', 'o', 'ordinary', '1month', ''),
(2, 1, '2017-03-07 02:04:36', 'uu', 'uu', 'male', 'i', 'i', 'kk', 'k', 'k', '', 'kkk', 'air bus', '2month', '');

-- --------------------------------------------------------

--
-- Table structure for table `renewal`
--

CREATE TABLE IF NOT EXISTS `renewal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `name` varchar(100) NOT NULL,
  `mobileno` int(100) NOT NULL,
  `amount` int(100) NOT NULL,
  `validate` int(100) NOT NULL,
  `to` int(100) NOT NULL,
  `startpoint` varchar(100) NOT NULL,
  `endpoint` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `renewal`
--


-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` int(11) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_name` varchar(100) NOT NULL,
  `display_name` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `pin_code` int(50) NOT NULL,
  `mobileno` int(50) NOT NULL,
  `email_id` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `status`, `created_at`, `user_name`, `display_name`, `city`, `pin_code`, `mobileno`, `email_id`, `password`) VALUES
(1, 1, '2017-02-14 02:58:37', 'suga', 'suganya', 'tamilnadu', 123456, 0, 'suganya@gmail.com', '890'),
(2, 1, '2017-02-14 03:00:12', '', '', '', 0, 0, '', ''),
(3, 1, '2017-02-14 03:00:30', '', '', '', 0, 0, '', ''),
(4, 1, '2017-02-14 03:02:15', 'suga', 'suganya', 'tamilnadu', 123456, 0, 'suganya@gmail.com', '890'),
(5, 1, '2017-02-21 02:36:52', 'ttt', 'rr', 'xxx', 488, 0, '2222 @gmal.com', '8888'),
(6, 1, '2017-02-21 02:38:07', 'ttt', 'rr', 'xxx', 488, 0, '2222 @gmal.com', '8888'),
(7, 1, '2017-02-21 02:43:51', 'suga', 'suganya', 'tamilnadu', 123456, 0, 'suganya@gmail.com', '899'),
(8, 1, '2017-02-23 02:53:25', 'sneha Janardhanan', 'sneha', 'coimbtore', 641301, 0, 'snehabc1b@gmail.com', 'neha'),
(9, 1, '2017-02-23 02:55:31', 'sneha Janardhanan', 'sneha', 'coimbtore', 641301, 0, 'snehabc1b@gmail.com', 'sneha'),
(10, 1, '2017-03-03 04:02:12', '', '', '', 0, 0, '', ''),
(11, 1, '2017-03-03 08:15:53', '', '', '', 0, 0, '', ''),
(12, 1, '2017-03-03 08:19:46', '', '', '', 0, 0, '', 'sneha'),
(13, 1, '2017-03-06 08:05:37', '', '', '', 0, 0, '', 'sneha'),
(14, 1, '2017-03-06 08:05:45', '', '', '', 0, 0, '', 'sneha'),
(15, 1, '2017-03-06 08:51:00', 'p', 'suganya', 'coimbtore', 123456, 0, 'suganya@gmail.com', '123'),
(16, 1, '2017-03-07 02:57:45', 'suga', 'sugan', 'tamilnadu', 641301, 0, 'sugan@gmail.com', '123456'),
(17, 1, '2017-03-07 02:58:54', '', '', '', 0, 0, '', 'sneha'),
(18, 1, '2017-03-07 02:59:59', 'suby', 'suby', 'cbe', 123456, 0, 'snehabc1b@gmail.com', '123'),
(19, 1, '2017-03-07 03:00:29', 'suby', 'suby', 'cbe', 123456, 0, 'suby@gmail.com', ''),
(20, 1, '2017-03-07 03:06:24', 'suby', 'suby', 'tamilnadu', 641301, 0, 'sugan', 'sneha'),
(21, 1, '2017-03-07 03:06:48', 'suby', 'suby', 'tamilnadu', 641301, 0, 'a@gmail.com', '123');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
