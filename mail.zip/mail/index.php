<?php
include('config.php');
if(isset($_POST['submit']))
{
$email=$_POST['em'];
$query=mysql_query("select * from mailto where mailid='$email'");
$row=mysql_fetch_array($query);
echo $row['id'];
if($query)
{
header('location:forgotpass.php?id='.$row['id']);
}
}
?>
<html>
<body>
<form method="post">
<label>Email</label>
<input type="text" name="em">
<input type="submit" name="submit" value="forgot">
</form>
</body>
</html>